<div class="py-3">
	<h2>Sidebar</h2>
	<p>This is an example of sidebar below the placeholder. It can be used for advertising banners or custom notes.</p>
	<p>Place here your contents, or remove the file <code>/template/<span class="bg-danger text-white px-1">sidebar.php</span></code>.</p>
</div>